# 第三方材料、许可与修改说明

本插件为 `CAND-CLD-022` / `AH-20261030-pdf-viewer` 的 WorkSwarm 原生适配。保留上游原始许可与署名，不表示获得任何上游方的官方背书。

## 上游一：Anthropic Claude 插件包 PDF Viewer（Apache-2.0）

- 来源：https://github.com/anthropics/knowledge-work-plugins/tree/2574e29377c7173d0cecffef29a6ecbd7f8ccb5d/pdf-viewer
- 固定修订：`2574e29377c7173d0cecffef29a6ecbd7f8ccb5d`（目录内 `.claude-plugin/plugin.json` 声明版本 `0.2.0`，作者 Anthropic）
- 适用许可：Apache License 2.0。完整文本见 `licenses/claude-knowledge-work-plugins/LICENSE`（SHA-256 `cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30`），已逐字节保留，未做修改。
- 该目录在本修订下没有单独的 NOTICE 文件，故本包不附 NOTICE，也不虚构署名内容。

| 复用材料 | 交付路径 | 修改说明 |
| --- | --- | --- |
| `skills/view-pdf/SKILL.md` | `skills/pdf-viewer/SKILL.md` | 依 Apache-2.0 第 4(b) 条改写：全文改为简体中文并按工作流重排；补充工具调用顺序、坐标与标注类型表、批注/表单/签名三段流程、文件访问边界、宿主查看器缺失（`Viewer never connected`）与参数错误的处理说明；删除上游对 Claude Code 专有的 slash command 与 CONNECTORS 引用；Skill 名改为 `pdf-viewer` 以匹配本包目录。 |
| `.mcp.json` | `mcps/pdf-viewer/mcp.json` | 依 Apache-2.0 第 4(b) 条改写：服务名由 `pdf` 改为 `pdf-viewer`；启动命令由未固定版本的 `npx -y @modelcontextprotocol/server-pdf --stdio` 改为固定 `@modelcontextprotocol/server-pdf@2.0.4` 并显式指定 npm registry；新增超时、中文服务说明与前置条件描述。 |
| `README.md`、`commands/*.md`、`CONNECTORS.md` | 未随包分发 | 其功能与命令语义已并入上述中文 Skill 与包内 `README.md`，不再单独复制原文件。 |

## 上游二：PDF MCP 服务（MIT，运行时获取，不重分发）

- 包：`@modelcontextprotocol/server-pdf@2.0.4`
- 仓库：https://github.com/modelcontextprotocol/ext-apps ，目录 `examples/pdf-server`，固定修订 `7af9a75da720b8a81be0f9aff47b25f75e9530ad`（即该 npm 版本的 `gitHead`）
- 许可：`package.json` 声明 MIT；仓库根 `LICENSE` 载明该项目正处于 MIT → Apache-2.0 的过渡说明。完整文本见 `licenses/modelcontextprotocol-ext-apps/LICENSE`（SHA-256 `0382b0057770ca05e9c350a50aa3b1c1fea84da0bc81d723bf00b9aa841be58a`）。
- **分发边界**：本包不复制、不打包该服务的任何实现文件，也不附带 `node_modules`。用户机器上的 `npx` 在首次启动时按固定版本从 npm 拉取，由用户依其原始许可获得副本。

## 运行时依赖

首次启动时由 `npx` 安装的依赖（`zod`、`express`、`cors`、`pdfjs-dist`、`@cantoo/pdf-lib`、`@modelcontextprotocol/{node,client,server,express,ext-apps}`）各自适用其原始许可。本包不分发这些实现，因此不在仓库内复制其许可文件；若将来决定内置依赖，必须另行完成逐包许可复核并在此登记。

## 未复制的内容

上游的 `.claude-plugin/` 清单、slash command 文件、`CONNECTORS.md`、图标、截图、演示素材与任何账号凭据均未进入本包。本包不包含任何上游商标或品牌素材。

## 新写内容

`manifest.json`、`asset.json`、`provenance.json`、`SOURCE_REVIEW.md`、`TEST_REPORT.md`、中文 `README.md`、MCP 服务说明文字、测试脚本与测试报告均为本任务的适配工作，不属于上游材料。
