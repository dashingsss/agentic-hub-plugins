# PDF阅览与批注助手

上游 PDF Viewer 0.2.0 → 中文展示名 PDF阅览与批注助手 → 内部 slug `pdf-viewer`。候选 `CAND-CLD-022`，任务 `AH-20261030-pdf-viewer`，负责人 Nguyen Trung Dung。

在宿主提供的交互查看器中打开 PDF，并按批次协作批注：高亮、便签、印章、签名图、表单填写，最后另存标注副本。插件只注册本地 MCP 服务，不保存文档内容，也不需要账号或 API key。

## 主要能力

- 列出可读的本地 PDF 与允许目录（`list_pdfs`）。
- 打开本地或受支持的 HTTPS 文档并取得 `viewUUID`（`display_pdf`）。
- 批量执行批注、导航、检索、文本/截图提取与表单填写（`interact`）。
- 另存标注副本（`interact` → `save_as`）。

## 安装与使用

在兼容宿主的扩展面板导入 `pdf-viewer-1.0.0-native-test.zip`，确认版本 `1.0.0`，然后在新会话中选中该插件。

示例指令：

- "打开工作目录里的 sample.pdf，先只做只读检查，不要加批注。"
- "把第 2 页的终止条款高亮出来，加一条便签'复核 30 天窗口'，再在第 1 页盖 DRAFT 印章。"
- "这份表单有可填字段，按截图里的视觉标签帮我逐项填写。"

具体工具顺序、坐标约定和工作流见 `skills/pdf-viewer/SKILL.md`。

## 必要依赖

- Node.js >= 20。`npx` 首次启动会按固定版本安装 `@modelcontextprotocol/server-pdf@2.0.4`，需要网络；之后可离线复用缓存。
- 宿主必须能渲染 MCP App 交互查看器。交互类操作依赖查看器回轮询命令队列；宿主不渲染时 `interact` 约 8 秒后返回 `Viewer never connected`。
- 受支持的远程来源包括 arXiv、bioRxiv、medRxiv、chemRxiv、Zenodo、OSF、HAL、SSRN 等 HTTPS 地址。

## 适用范围与限制

- 只做"看着文档一起改"的可视流程。纯摘要或纯文本抽取请用宿主原生文件读取。
- 签名只是把图片贴到页面上，**不是**具备法律效力的数字签名；合规电子签名需另行使用专门服务。
- 本包只固定了 MCP 服务版本，未附带 Node 运行时，也未附带该服务的依赖目录；依赖由 `npx` 在用户机器上按各自许可安装。
- 交互查看器在 WorkSwarm 中的实际渲染能力尚未由本包验证；本轮只验证了服务端在有/无查看器两种情况下的行为。宿主能力以用户实测为准。

## 来源与许可

- Claude 插件包 `anthropics/knowledge-work-plugins` 固定提交 `2574e29377c7173d0cecffef29a6ecbd7f8ccb5d` 的 `pdf-viewer` 目录，Apache-2.0。本包复用并中文化其 Skill 指令与 MCP 启动配置，完整许可见 `licenses/claude-knowledge-work-plugins/LICENSE`。
- 运行时服务 `@modelcontextprotocol/server-pdf@2.0.4`（仓库 `modelcontextprotocol/ext-apps`，提交 `7af9a75da720b8a81be0f9aff47b25f75e9530ad`），MIT。本包**不重分发**其代码，只在运行时由 `npx` 拉取；其许可文本一并保留在 `licenses/modelcontextprotocol-ext-apps/LICENSE` 备查。
- 逐文件修改说明见 `THIRD_PARTY_NOTICES.md`。保留原始许可与署名不表示获得 Anthropic 或 MCP 项目官方背书。
