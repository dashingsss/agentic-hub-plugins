---
name: pdf-viewer
description: 通过本地 PDF MCP 服务打开并协作审阅 PDF：在宿主查看器中高亮、加便签、盖章、放置签名图、填写表单字段并另存标注副本。仅用于"看着文档一起改"的可视流程；若用户只想要摘要或纯文本抽取，应改用宿主自带的文件读取能力。
---

# PDF 阅览与批注

本插件注册本地 MCP 服务 `pdf-viewer`（`@modelcontextprotocol/server-pdf` 2.0.4，stdio）。所有操作都通过该服务的工具完成，插件本身不保存任何文档内容。

## 何时使用

适合：

- "打开这份合同 / 论文给我看"
- "把关键条款高亮出来，我逐段确认"
- "帮我填这份表单"
- "在第 3 页签名 / 每页加首字母"
- "盖一个 CONFIDENTIAL 印章"

不适合（改用宿主原生文件读取）：

- "总结这份 PDF"
- "第 5 页写了什么"
- "把第 3 节的表格抽出来"

## 前置条件

- Node.js >= 20；首次调用时 `npx` 需要联网安装固定版本依赖。
- 宿主必须能渲染 MCP App 交互查看器。**交互类操作依赖查看器回轮询命令队列**；若宿主不渲染，`interact` 会在约 8 秒后返回 `Viewer never connected`。
- 文档来源：启动参数中登记过的本地文件（`list_pdfs` 可见）、客户端 roots 下的目录，或受支持的 HTTPS 地址（arXiv、bioRxiv、medRxiv、chemRxiv、Zenodo、OSF、HAL、SSRN 等）。

## 工具与调用顺序

1. `list_pdfs`：无参数，返回可读的本地 PDF 与允许目录。用户未给路径时先调用它。
2. `display_pdf`：`url`（本地路径或 HTTPS 地址）、`page`（可选，默认 1）、`elicit_form_inputs`（可选）。返回 `viewUUID`、`totalBytes` 和（有表单时）`formFields`。
3. `interact`：后续所有操作用它，必须带 `display_pdf` 返回的 `viewUUID`，通过 `commands` 数组批量执行，命令按顺序运行，结果按同样顺序返回。
4. `read_pdf_bytes`：查看器分块读取 PDF 字节，通常由查看器自己调用。

**同一个文档只调用一次 `display_pdf`。** 再次调用会生成新的 `viewUUID` 和新的空查看器，之前的 `interact` 目标就与用户正在看的文档不一致了。

## interact 命令

- 标注：`add_annotations`、`update_annotations`、`remove_annotations`、`highlight_text`（按文本自动找矩形，优先于手写 `rects`）
- 导航：`navigate`（页码）、`search`、`find`、`search_navigate`、`zoom`（0.5–3.0）
- 提取：`get_text`（每次最多 20 页，用于决定标注什么，不用于总结）、`get_screenshot`（页面截图，用于核对结果）
- 表单：`fill_form`（`fields: [{name, value}]`）
- 保存：`save_as`、`get_viewer_state`

## 标注对象与坐标

每个标注需要 `id`（唯一字符串）、`type`、`page`（从 1 开始）。坐标单位是 PDF 点（1 点 = 1/72 英寸），原点在页面**左上角**，Y 轴向下增大。US Letter 为 612×792 点；页边距大约上 50、下 742、左 72、右 540。

| 类型 | 关键字段 | 用途 |
| --- | --- | --- |
| `highlight` | `rects`、`color?`、`content?` | 标记重要文字 |
| `underline` | `rects`、`color?` | 强调条款 |
| `strikethrough` | `rects`、`color?` | 标记删除 |
| `note` | `x`、`y`、`content` | 便签评论 |
| `freetext` | `x`、`y`、`content`、`fontSize?` | 页面上可见文字 |
| `rectangle` / `circle` | `x`、`y`、`width`、`height` | 框选区域 |
| `line` | `x1`、`y1`、`x2`、`y2` | 连线 |
| `stamp` | `x`、`y`、`label` | 印章文字，如 APPROVED、DRAFT、CONFIDENTIAL |
| `image` | `imageUrl`、`x?`、`y?`、`width?` | 签名图、首字母、logo |

矩形/圆形/印章的 `x`、`y` 是左上角。`imageUrl` 接受本地路径或 HTTPS 地址，不支持 `data:` URI。

## 工作方式

批注（默认流程）：

1. `display_pdf` 打开文档；
2. `interact` → `get_text` 读取相关页，理解内容；
3. 先向用户说明准备加哪些标注（位置 + 内容 + 印章文字），等确认；
4. 确认后 `interact` → `add_annotations`，并在同一批次结尾加 `get_screenshot` 核对；
5. 把截图结果反馈给用户，按意见用 `update_annotations` / `remove_annotations` 调整；
6. 每批控制在 3–5 个标注，逐段推进；
7. 结束时提醒用户可在查看器工具栏下载标注副本。

表单填写：

1. `display_pdf` 后检查返回的 `formFields`（名称、类型、页码、边界框）；
2. 字段名是 `Text1`、`Field_7` 这类机器名时，用 `get_screenshot` 看页面上印刷的标签，再决定字段对应什么；
3. 值从对话上下文推断，或按视觉标签向用户逐项询问；
4. `interact` → `fill_form`，随后 `get_screenshot` 核对；
5. 签名字段通常单独处理，文字填完后再用 `image` 标注放签名图。

签名：

1. 先向用户索取本地签名图路径（PNG/JPG）；
2. `display_pdf` 后查看 `formFields` 中是否有签名域及其坐标；
3. 没有签名域时向用户确认页码和大致位置；
4. `interact` → `add_annotations` 放 `image`，可省略 `width`/`height` 由服务自动按图比例计算；
5. `get_screenshot` 核对位置，必要时 `update_annotations` 微调；
6. 多页首字母可在一次 `add_annotations` 中每页放一个 `image`。

## 必须遵守的边界

- **不要声称这是具备法律效力的数字签名。** 这里只是把签名图片贴到页面上；需要合规电子签名时应改用专门的签署服务。
- 不替用户编造事实：表单里的姓名、证件号、金额、日期等必须来自用户或对话中已确认的内容。
- `get_text` 抽取的文字只用于决定标注位置，不作为文档摘要的交付物。
- 不要尝试绕过文件访问限制：只有启动参数登记的文件、客户端 roots 下的路径和受支持的 HTTPS 来源可读。
- 覆盖写回仅在文件来自启动参数或位于允许目录内时才被接受；不确定时用 `save_as` 另存新文件，不要覆盖原稿。

## 错误处理

- `Viewer never connected for viewUUID ...`：宿主没有挂载查看器（或会话在查看器加载前就空闲了）。这是宿主能力问题，不要反复重试同一 `viewUUID`；向用户说明"当前宿主无法渲染交互查看器，只能做只读检查"，并只使用 `list_pdfs`、`display_pdf` 的元数据结果。
- `Local file not in allowed list`：该路径未登记。先用 `list_pdfs` 确认可读范围，再让用户把文件放到允许目录，或改用受支持的 HTTPS 地址。
- `Input validation error: ... commands.N.action: Invalid option`：`interact` 的 `action` 不在支持的枚举内，按上表改正拼写；这类错误在服务端入参校验阶段直接返回，不会进入查看器队列。
- `ERROR:` 前缀（批处理中途失败）：`content` 数组长度表示执行到第几步，修正失败的那一步后从该步重发，不必重复已成功的命令。
- 参数校验失败（缺少 `page`、`id` 重复、坐标超出页面）：先修正参数，不要靠重试碰运气。
